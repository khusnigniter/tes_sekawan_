<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
        parent::__construct();
 
    }

	public function index()
	{
		//header('Content-type: application/json');
		$url = "./public/data.json";
		$get_url = file_get_contents($url);
		$data = json_decode($get_url, true);
		//var_dump($data);
		//$data_encode = json_encode($data_decode);
		//$data = file_put_contents($url, $data_encode);
		$data_array = array(
			'title' => 'Sekawan Tes',
			'datalist' => $data 
			);
		$this->load->view('welcome_message', $data_array);
	}
}
