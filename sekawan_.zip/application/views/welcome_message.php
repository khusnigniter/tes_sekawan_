<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?= $title;?></title>

	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/style.css');?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">

</head>
<body>
<div class="container my-5">
	<div class="row">
		<div class="card">
			<div class="card-header">
				<div class="card-title"><a href="#" class="btn btn-success">Tambah</a>&nbsp;<a href="#" class="btn btn-dark float-right">Refresh</a></div>
			</div>
			<div class="card-body table-responsive">
				<table class="table table-striped" id="datalist">
					<thead>
						<tr>
							<th>No</th>
							<th>ID Reg</th>
							<th>Nama Pegawai</th>
							<th>Gaji</th>
							<th>Usia</th>
							<th>Foto</th>
						</tr>	
					</thead>
					<tbody id="listRecord">
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>

<!-- JS Script -->
<script type="text/javascript" src="<?= base_url('assets/js/jquery-3.5.1.min.js');?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
<script type="text/javascript">
$(document).ready(function() {
  
  $.ajax({
    url: "<?= site_url('welcome/index/')?>",
    type: "GET",
    dataType: "JSON",
    success: function(data) {
      if (data[0] === undefined) return;
      $('#id').text(data[0].id);
      $('#employee_name').text(data[0].employee_name);
      $('#employee_salary').text(data[0].employee_salary);
      $('#employee_age').text(data[0].employee_age);
      $('#profile_image').text(data[0].profile_image);
    }
  });
})
</script>
</body>
</html>